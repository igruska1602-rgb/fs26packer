package com.fs26.packer

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

typealias Logger = (String, String) -> Unit

private const val DESC_VERSION = "2" // взято из рабочей мобильной карты
private const val REPORT_LIMIT = 200

private val SKIP_NAMES = setOf("thumbs.db", ".ds_store", "desktop.ini")
private val SKIP_EXT = setOf(".bak", ".tmp", ".blend1")
private val SKIP_DIRS = setOf("__pycache__", ".git", "__MACOSX")
private val STORED_EXT = listOf(".png", ".jpg", ".jpeg", ".zip") // уже сжаты
private val SCRIPT_XMLS = setOf(
    "collectibles", "farmlands", "fields", "items", "placeables", "storeitems", "vehicles"
)
private val PATH_ATTRS = listOf(
    "filename", "imageFilename", "xmlFilename", "iconFilename", "configFilename",
    "defaultVehiclesXMLFilename", "defaultPlaceablesXMLFilename",
    "defaultItemsXMLFilename", "defaultHandToolsXMLFilename"
)

private val FILE_RE = Regex("<File\\b[^>]*?\\bfilename=\"([^\"]+)\"")
private val ICON_PREVIEW_RE = Regex("(icon|preview).*\\.(png|dds)")
private val TEX_RE = Regex("_(diffuse|normal|height|displacement|specular)\\.(png|dds)$")
private val CFG_RE = Regex("maps/[^/]+\\.xml")
private val ICON_FILE_RE = Regex("icon[^/]*\\.png", RegexOption.IGNORE_CASE)
private val EMBEDDED_RE = Regex("embeddedMods/[^/]+/[^/]+\\.xml")
private val REGISTER_RE = Regex("register.*\\.lua", RegexOption.IGNORE_CASE)
private val NONASCII_RE = Regex("[^\\x21-\\x7e]")

class Options(
    val title: String,
    val author: String,
    val version: String,
    val sort: Boolean,
    val force: Boolean
)

class Prepared(
    val fin: LinkedHashMap<String, String>, // исходный путь -> путь в готовом zip
    val modDesc: String?,                   // текст созданного modDesc.xml (если его не было)
    val errors: Int
)

class Info(val orig: String, val size: Long) {
    var rootTag: String? = null
    var broken = false
    val refs = ArrayList<String>()
    var descVersion: String? = null
    var hasMap = false
    var hasVersion = false
    var hasAuthor = false
}

fun safeName(s: String): String {
    val r = s.replace(Regex("[^A-Za-z0-9_]+"), "_").trim('_')
    return if (r.isEmpty()) "Map" else r
}

private fun skipped(name: String): Boolean {
    val parts = name.split("/")
    val base = parts.last().lowercase()
    val dot = base.lastIndexOf('.')
    val ext = if (dot > 0) base.substring(dot) else ""
    return base in SKIP_NAMES || ext in SKIP_EXT || parts.dropLast(1).any { it in SKIP_DIRS }
}

private fun esc(s: String) =
    s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

private fun norm(p: String): String {
    val out = ArrayList<String>()
    for (s in p.split('/')) {
        when (s) {
            "", "." -> {}
            ".." -> if (out.isNotEmpty()) out.removeAt(out.size - 1) else out.add("..")
            else -> out.add(s)
        }
    }
    return out.joinToString("/")
}

// ------------------------------------------------------------------ источники
interface Source {
    val baseName: String
    /** Вызывает cb для каждого файла. stream() надо прочитать внутри cb. */
    fun each(cb: (name: String, size: Long, stream: () -> InputStream) -> Unit)
}

class ZipSource(
    private val cr: ContentResolver,
    private val uri: Uri,
    override val baseName: String
) : Source {
    override fun each(cb: (String, Long, () -> InputStream) -> Unit) {
        val raw = cr.openInputStream(uri) ?: throw java.io.IOException("Не удалось открыть zip")
        ZipInputStream(BufferedInputStream(raw, 1 shl 16)).use { zin ->
            val wrapper = object : FilterInputStream(zin) {
                override fun close() {}
            }
            while (true) {
                val e = zin.nextEntry ?: break
                if (e.isDirectory) continue
                val n = e.name.replace('\\', '/')
                if (skipped(n)) continue
                cb(n, e.size, { wrapper })
            }
        }
    }
}

class DirSource(
    private val cr: ContentResolver,
    private val tree: Uri,
    override val baseName: String
) : Source {
    private class F(val rel: String, val uri: Uri, val size: Long)

    override fun each(cb: (String, Long, () -> InputStream) -> Unit) {
        val files = ArrayList<F>()
        fun walk(docId: String, prefix: String) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            )
            cr.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (name !in SKIP_DIRS) walk(id, "$prefix$name/")
                    } else {
                        val rel = prefix + name
                        if (!skipped(rel)) {
                            files.add(F(rel, DocumentsContract.buildDocumentUriUsingTree(tree, id), size))
                        }
                    }
                }
            }
        }
        walk(DocumentsContract.getTreeDocumentId(tree), "")
        files.sortBy { it.rel }
        for (f in files) {
            cb(f.rel, f.size, {
                val raw = cr.openInputStream(f.uri)
                    ?: throw java.io.IOException("Не удалось открыть ${f.rel}")
                BufferedInputStream(raw, 1 shl 16)
            })
        }
    }
}

// ------------------------------------------------------------------ чтение xml / i3d
private fun parseXml(ins: InputStream, inf: Info) {
    try {
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(ins, null)
        val stack = ArrayList<String>()
        val hasChild = ArrayList<Boolean>()
        val cur = StringBuilder()
        val refs = ArrayList<String>()
        var root: String? = null
        var dv: String? = null
        var map = false
        var ver = false
        var auth = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    val name = p.name
                    if (stack.isEmpty()) {
                        root = name
                        dv = p.getAttributeValue(null, "descVersion")
                    } else {
                        hasChild[hasChild.size - 1] = true
                        if (root == "modDesc") {
                            if (stack.size == 1 && name == "version") ver = true
                            if (stack.size == 1 && name == "author") auth = true
                            if (stack.size == 2 && stack[1] == "maps" && name == "map") map = true
                        }
                    }
                    for (a in PATH_ATTRS) {
                        val v = p.getAttributeValue(null, a)
                        if (!v.isNullOrEmpty()) refs.add(v)
                    }
                    stack.add(name)
                    hasChild.add(false)
                    cur.setLength(0)
                }
                XmlPullParser.TEXT -> cur.append(p.text)
                XmlPullParser.END_TAG -> {
                    val name = p.name
                    if (!hasChild[hasChild.size - 1] &&
                        (name == "filename" || name == "image" || name == "icon")
                    ) {
                        val t = cur.toString().trim()
                        if (t.isNotEmpty()) refs.add(t)
                    }
                    stack.removeAt(stack.size - 1)
                    hasChild.removeAt(hasChild.size - 1)
                    cur.setLength(0)
                }
                else -> {}
            }
            ev = p.next()
        }
        if (root == null) {
            inf.broken = true
            return
        }
        inf.rootTag = root
        inf.refs.addAll(refs)
        inf.descVersion = dv
        inf.hasMap = map
        inf.hasVersion = ver
        inf.hasAuthor = auth
    } catch (e: Exception) {
        inf.broken = true
        inf.rootTag = null
        inf.refs.clear()
    }
}

private fun parseI3d(ins: InputStream, inf: Info) {
    try {
        BufferedReader(InputStreamReader(ins, Charsets.ISO_8859_1), 1 shl 16).use { r ->
            while (true) {
                val line = r.readLine() ?: break
                for (m in FILE_RE.findAll(line)) inf.refs.add(m.groupValues[1])
            }
        }
    } catch (e: Exception) {
        // нечитаемый i3d: ссылки просто не проверяются
    }
}

// ------------------------------------------------------------------ проход 1: чтение структуры
fun scan(src: Source): LinkedHashMap<String, Info> {
    val m = LinkedHashMap<String, Info>()
    src.each { name, size, stream ->
        val inf = Info(name, if (size < 0) 0L else size)
        val l = name.lowercase()
        if (l.endsWith(".xml")) {
            stream().use { parseXml(it, inf) }
        } else if (l.endsWith(".i3d")) {
            stream().use { parseI3d(it, inf) }
        }
        m[name] = inf
    }
    return m
}

// ------------------------------------------------------------------ раскладка по папкам
private fun plan(infos: Map<String, Info>, sort: Boolean, log: Logger): LinkedHashMap<String, String> {
    val fin = LinkedHashMap<String, String>()
    for (k in infos.keys) fin[k] = k

    val tops = infos.keys.map { if ('/' in it) it.substringBefore('/') else null }.toSet()
    if (tops.size == 1 && null !in tops) {
        val top = tops.first()!!
        if (top != "maps" && top != "embeddedMods") {
            log("WARN", "Всё лежит во вложенной папке $top: использую её как корень")
            val pre = "$top/"
            for (k in infos.keys) fin[k] = k.substring(pre.length)
        }
    }
    if (sort) sortLoose(infos, fin, log)
    return fin
}

private fun sortLoose(infos: Map<String, Info>, fin: LinkedHashMap<String, String>, log: Logger) {
    val loose = fin.entries.filter { '/' !in it.value }.map { it.key }
    var mapname = "map"
    for (o in loose) {
        val f = fin[o]!!
        val lf = f.lowercase()
        if (lf.endsWith(".i3d") && !lf.startsWith("sounds")) {
            mapname = f.dropLast(4)
            break
        }
    }
    val used = HashSet<String>(fin.values)
    var moved = 0
    for (o in loose) {
        val k = fin[o]!!
        val l = k.lowercase()
        val stem = l.substringBefore('.')
        if (l == "moddesc.xml" || l.endsWith(".lua") || ICON_PREVIEW_RE.matches(l)) continue
        val dst: String = when {
            stem in SCRIPT_XMLS && l.endsWith(".xml") -> "maps/scripts"
            l.startsWith("sounds.") || l.startsWith("overview.") -> "maps"
            l.endsWith(".gdm") || l.endsWith(".grle") || "_weight." in l ||
                l.startsWith("dem.") || l.startsWith("blockmask") ||
                l.startsWith("gen_") || l.startsWith("infolayer_") -> "maps/data"
            l.endsWith(".ast") -> "maps/$mapname/fillPlanes"
            TEX_RE.containsMatchIn(l) -> "maps/$mapname/textures/terrain"
            ".i3d" in l -> "maps"
            l.endsWith(".xml") && infos[o]?.rootTag == "map" -> "maps"
            else -> {
                log("WARN", "Не знаю, куда положить: $k (оставлено в корне)")
                continue
            }
        }
        val nf = "$dst/$k"
        if (nf in used) {
            log("WARN", "Файл $nf уже существует, $k оставлен в корне")
            continue
        }
        used.remove(k)
        used.add(nf)
        fin[o] = nf
        moved++
    }
    log("INFO", "Разложено файлов: $moved")
}

// ------------------------------------------------------------------ modDesc.xml
private fun genModDesc(
    byFinal: Map<String, Info>, title: String, author: String, version: String, log: Logger
): String? {
    val rels = byFinal.keys.sorted()
    val cfg = rels.firstOrNull { CFG_RE.matches(it) && byFinal[it]?.rootTag == "map" }
    if (cfg == null) {
        log("ERR", "Не нашёл конфиг карты (maps/*.xml с тегом <map>). modDesc не создан.")
        return null
    }
    val icon = rels.firstOrNull { ICON_FILE_RE.matches(it) } ?: ""
    val preview = if ("preview.png" in byFinal) "preview.png" else icon
    if (icon.isEmpty()) log("WARN", "Нет icon*.png в корне — добавь иконку мода.")

    fun opt(attr: String, path: String) = if (path in byFinal) " $attr=\"$path\"" else ""

    val items = rels.filter {
        EMBEDDED_RE.matches(it) && byFinal[it]?.rootTag in setOf("placeable", "vehicle", "handTool")
    }
    val luas = rels.filter { '/' !in it && REGISTER_RE.matches(it) }
    val t = esc(title)

    val sb = StringBuilder()
    sb.append("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\" ?>\n")
    sb.append("<modDesc descVersion=\"$DESC_VERSION\">\n")
    sb.append("    <author>${esc(author)}</author>\n")
    sb.append("    <version>${esc(version)}</version>\n")
    sb.append("    <title><en>$t</en><uk>$t</uk></title>\n")
    sb.append("    <description><en>$t</en><uk>$t</uk></description>\n")
    sb.append("    <iconFilename>$icon</iconFilename>\n")
    sb.append("    <multiplayer supported=\"true\" />\n")
    sb.append("    <maps>\n")
    sb.append("        <map id=\"${safeName(title)}\" className=\"Mission00\" ")
    sb.append("filename=\"\$dataS/scripts/mission00.lua\" configFilename=\"$cfg\"")
    sb.append(opt("defaultVehiclesXMLFilename", "maps/scripts/vehicles.xml"))
    sb.append(" defaultHandToolsXMLFilename=\"\$dataS/maps/handTools.xml\"")
    sb.append(opt("defaultPlaceablesXMLFilename", "maps/scripts/placeables.xml"))
    sb.append(opt("defaultItemsXMLFilename", "maps/scripts/items.xml"))
    sb.append(">\n")
    sb.append("            <title><en>$t</en></title>\n")
    sb.append("            <description><en>$t</en></description>\n")
    sb.append("            <iconFilename>$preview</iconFilename>\n")
    sb.append("        </map>\n")
    sb.append("    </maps>\n")
    if (items.isNotEmpty()) {
        sb.append("    <storeItems>\n")
        for (r in items) sb.append("        <storeItem xmlFilename=\"$r\" />\n")
        sb.append("    </storeItems>\n")
    }
    if (luas.isNotEmpty()) {
        sb.append("    <extraSourceFiles>\n")
        for (l in luas) sb.append("        <sourceFile filename=\"$l\" />\n")
        sb.append("    </extraSourceFiles>\n")
    }
    sb.append("</modDesc>\n")
    log("INFO", "Создан modDesc.xml (карта: $cfg, встроенных предметов: ${items.size})")
    return sb.toString()
}

// ------------------------------------------------------------------ проверка
private fun check(byFinal: Map<String, Info>, log: Logger): Int {
    val low = HashMap<String, String>()
    for (k in byFinal.keys) low[k.lowercase()] = k
    var errs = 0
    var warns = 0

    fun rep(level: String, msg: String) {
        if (level == "ERR") {
            errs++
            if (errs <= REPORT_LIMIT) log(level, msg)
        } else {
            warns++
            if (warns <= REPORT_LIMIT) log(level, msg)
        }
    }

    fun verify(rel0: String, base: String, owner: String) {
        if (rel0.isEmpty() || rel0.startsWith('$') || "://" in rel0) return
        val rel = rel0.replace('\\', '/')
        val p = norm(if (base.isEmpty()) rel else "$base/$rel")
        if (p in byFinal) return
        val hit = low[p.lowercase()]
        if (hit != null) {
            rep("ERR", "$owner: $rel -> в zip файл называется $hit (Android чувствителен к регистру!)")
        } else {
            rep("ERR", "$owner: не найден файл $rel")
        }
    }

    if ("modDesc.xml" !in byFinal) rep("ERR", "modDesc.xml должен лежать в корне zip.")
    for (r in byFinal.keys.sorted()) {
        val inf = byFinal[r]!!
        if (NONASCII_RE.containsMatchIn(r)) {
            rep("WARN", "Пробелы или не-латинские символы в имени: $r")
        }
        val lr = r.lowercase()
        if (lr.endsWith(".i3d") && "$r.shapes" !in byFinal) {
            rep("WARN", "Нет $r.shapes (если в i3d есть геометрия, игра её не загрузит)")
        }
        if (lr.endsWith(".xml")) {
            if (inf.broken || inf.rootTag == null) {
                rep("ERR", "Сломанный XML $r")
                continue
            }
            for (ref in inf.refs) verify(ref, "", r)
        } else if (lr.endsWith(".i3d")) {
            val dir = r.substringBeforeLast('/', "")
            for (ref in inf.refs) verify(ref, dir, r)
        }
    }
    val d = byFinal["modDesc.xml"]
    if (d != null && !d.broken && d.rootTag != null) {
        if (d.descVersion.isNullOrEmpty()) rep("ERR", "В modDesc.xml нет descVersion")
        if (!d.hasMap) rep("ERR", "В modDesc.xml нет блока <maps><map ...>")
        if (!d.hasVersion || !d.hasAuthor) rep("WARN", "В modDesc.xml нет <version> или <author>")
    }
    val total = byFinal.values.sumOf { it.size }
    log("INFO", "Файлов: ${byFinal.size}, размер: ${total / 1048576} МБ")
    if (errs > REPORT_LIMIT || warns > REPORT_LIMIT) {
        log("INFO", "Показаны первые $REPORT_LIMIT ошибок и $REPORT_LIMIT предупреждений каждого вида")
    }
    log("INFO", "Ошибок: $errs, предупреждений: $warns")
    return errs
}

// ------------------------------------------------------------------ подготовка (проход 1)
fun prepare(src: Source, o: Options, log: Logger): Prepared? {
    log("INFO", "Читаю структуру (ничего не распаковывается)...")
    val infos = scan(src)
    if (infos.isEmpty()) {
        log("ERR", "В выбранном zip/папке нет файлов")
        return null
    }
    log("INFO", "Найдено файлов: ${infos.size}")
    val fin = plan(infos, o.sort, log)
    val byFinal = LinkedHashMap<String, Info>()
    for ((orig, f) in fin) byFinal[f] = infos[orig]!!

    var md: String? = null
    if ("modDesc.xml" !in byFinal) {
        val title = o.title.ifBlank { src.baseName.replace('_', ' ') }
        val author = o.author.ifBlank { "Unknown" }
        val version = o.version.ifBlank { "1.0.0.0" }
        val gen = genModDesc(byFinal, title, author, version, log) ?: return null
        val bytes = gen.toByteArray(Charsets.UTF_8)
        val inf = Info("modDesc.xml", bytes.size.toLong())
        parseXml(ByteArrayInputStream(bytes), inf)
        byFinal["modDesc.xml"] = inf
        md = gen
    }
    val errs = check(byFinal, log)
    return Prepared(fin, md, errs)
}

// ------------------------------------------------------------------ упаковка (проход 2)
fun pack(src: Source, p: Prepared, out: OutputStream, log: Logger) {
    val total = p.fin.size + (if (p.modDesc != null) 1 else 0)
    var i = 0
    val seen = HashSet<String>()
    val buf = ByteArray(1 shl 20)
    val now = System.currentTimeMillis()
    ZipOutputStream(BufferedOutputStream(out, 1 shl 16)).use { z ->
        z.setLevel(1)
        val md = p.modDesc
        if (md != null) {
            val e = ZipEntry("modDesc.xml")
            e.time = now
            z.putNextEntry(e)
            z.write(md.toByteArray(Charsets.UTF_8))
            z.closeEntry()
            seen.add("modDesc.xml")
            i++
        }
        src.each { name, size, stream ->
            val f = p.fin[name] ?: return@each
            if (!seen.add(f)) {
                log("WARN", "Дубликат пропущен: $f")
                return@each
            }
            if (size >= 50L * 1048576) log("INFO", "Большой файл: $f (${size / 1048576} МБ)")
            val lf = f.lowercase()
            val e = ZipEntry(f)
            e.time = now
            z.setLevel(if (STORED_EXT.any { lf.endsWith(it) }) 0 else 1)
            z.putNextEntry(e)
            stream().use { ins ->
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    z.write(buf, 0, n)
                }
            }
            z.closeEntry()
            i++
            if (i % 100 == 0 || i == total) log("INFO", "Запаковано $i/$total")
        }
    }
}

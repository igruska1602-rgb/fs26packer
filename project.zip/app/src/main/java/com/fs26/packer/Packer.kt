package com.fs26.packer

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.concurrent.CancellationException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

// ------------------------------------------------------------------ язык
object Lang {
    @Volatile
    var uk = false
}

fun tr(ru: String, uk: String): String = if (Lang.uk) uk else ru

/** level: ERR, WARN, INFO, HINT */
typealias Logger = (String, String) -> Unit

private const val DESC_VERSION = "2" // взято из рабочей мобильной карты
private const val REPORT_LIMIT = 200

private val SKIP_NAMES = setOf("thumbs.db", ".ds_store", "desktop.ini")
private val SKIP_EXT = setOf(".bak", ".tmp", ".blend1")
internal val SKIP_DIRS = setOf("__pycache__", ".git", "__MACOSX")
private val STORED_EXT = listOf(".png", ".jpg", ".jpeg", ".zip") // уже сжаты
private val SCRIPT_XMLS = setOf(
    "collectibles", "farmlands", "fields", "items", "placeables", "storeitems", "vehicles"
)
private val PATH_ATTRS = listOf(
    "filename", "imageFilename", "xmlFilename", "iconFilename", "configFilename",
    "defaultVehiclesXMLFilename", "defaultPlaceablesXMLFilename",
    "defaultItemsXMLFilename", "defaultHandToolsXMLFilename"
)
private val PATH_TAGS = setOf("filename", "image", "icon", "iconFilename")

private const val IMG = "(png|dds|jpg|jpeg)"
private val FILE_RE = Regex("<File\\b[^>]*?\\bfilename=\"([^\"]+)\"")
private val ICON_PREVIEW_RE = Regex("(icon|preview).*\\.(png|dds)")
private val TEX_RE = Regex("_(diffuse|normal|height|displacement|specular)\\.(png|dds)$")
private val CFG_RE = Regex("maps/[^/]+\\.xml")
private val ICON_RE = Regex("icon[^/]*\\.$IMG", RegexOption.IGNORE_CASE)
private val PREVIEW_RE = Regex("preview[^/]*\\.$IMG", RegexOption.IGNORE_CASE)
private val OVERVIEW_RE = Regex("maps/(.*/)?overview[^/]*\\.$IMG", RegexOption.IGNORE_CASE)
private val EMBEDDED_RE = Regex("embeddedMods/[^/]+/[^/]+\\.xml")
private val REGISTER_RE = Regex("register.*\\.lua", RegexOption.IGNORE_CASE)
private val NONASCII_RE = Regex("[^\\x21-\\x7e]")

class Options(
    val title: String,
    val author: String,
    val version: String,
    val description: String,
    val sort: Boolean,
    val fixCase: Boolean,
    val force: Boolean,
    val icon: ByteArray?
)

class Prepared(
    val fin: LinkedHashMap<String, String>,      // исходный путь -> путь в готовом zip
    val extra: LinkedHashMap<String, ByteArray>, // файлы, созданные программой (modDesc.xml, иконка)
    val errors: Int,
    val warnings: Int
)

class Info(val orig: String, val size: Long) {
    var rootTag: String? = null
    var broken = false
    val refs = ArrayList<String>()
    var descVersion: String? = null
    var hasMap = false
    var hasVersion = false
    var hasAuthor = false
    var iconText: String? = null
}

fun safeName(s: String): String {
    val r = s.replace(Regex("[^A-Za-z0-9_]+"), "_").trim('_')
    return if (r.isEmpty()) "Map" else r
}

internal fun isSkipped(name: String): Boolean {
    val parts = name.split("/")
    val base = parts.last().lowercase()
    val dot = base.lastIndexOf('.')
    val ext = if (dot > 0) base.substring(dot) else ""
    return base in SKIP_NAMES || ext in SKIP_EXT || parts.dropLast(1).any { it in SKIP_DIRS }
}

private fun isStored(name: String): Boolean {
    val l = name.lowercase()
    return STORED_EXT.any { l.endsWith(it) }
}

private fun esc(s: String) =
    s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

private fun norm(p: String): String {
    val out = ArrayList<String>()
    for (s in p.split('/')) {
        when (s) {
            "", "." -> {}
            ".." -> if (out.isNotEmpty()) out.removeAt(out.size - 1) else out.add("..")
            else -> out.add(s)
        }
    }
    return out.joinToString("/")
}

// ------------------------------------------------------------------ источник
interface Source {
    val baseName: String

    /** Вызывает cb для каждого файла. stream() надо прочитать и закрыть внутри cb. */
    fun each(cb: (name: String, size: Long, stream: () -> InputStream) -> Unit)
}

// ------------------------------------------------------------------ чтение xml / i3d
internal fun parseXml(ins: InputStream, inf: Info) {
    try {
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(ins, null)
        val stack = ArrayList<String>()
        val hasChild = ArrayList<Boolean>()
        val cur = StringBuilder()
        val refs = ArrayList<String>()
        var root: String? = null
        var dv: String? = null
        var map = false
        var ver = false
        var auth = false
        var iconText: String? = null
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    val name = p.name
                    if (stack.isEmpty()) {
                        root = name
                        dv = p.getAttributeValue(null, "descVersion")
                    } else {
                        hasChild[hasChild.size - 1] = true
                        if (root == "modDesc") {
                            if (stack.size == 1 && name == "version") ver = true
                            if (stack.size == 1 && name == "author") auth = true
                            if (stack.size == 2 && stack[1] == "maps" && name == "map") map = true
                        }
                    }
                    for (a in PATH_ATTRS) {
                        val v = p.getAttributeValue(null, a)
                        if (!v.isNullOrEmpty()) refs.add(v)
                    }
                    stack.add(name)
                    hasChild.add(false)
                    cur.setLength(0)
                }
                XmlPullParser.TEXT -> cur.append(p.text)
                XmlPullParser.END_TAG -> {
                    val name = p.name
                    val leaf = !hasChild[hasChild.size - 1]
                    if (leaf && name in PATH_TAGS) {
                        val t = cur.toString().trim()
                        if (t.isNotEmpty()) refs.add(t)
                    }
                    if (leaf && root == "modDesc" && stack.size == 2 && name == "iconFilename") {
                        iconText = cur.toString().trim()
                    }
                    stack.removeAt(stack.size - 1)
                    hasChild.removeAt(hasChild.size - 1)
                    cur.setLength(0)
                }
                else -> {}
            }
            ev = p.next()
        }
        if (root == null) {
            inf.broken = true
            return
        }
        inf.rootTag = root
        inf.refs.addAll(refs)
        inf.descVersion = dv
        inf.hasMap = map
        inf.hasVersion = ver
        inf.hasAuthor = auth
        inf.iconText = iconText
    } catch (e: Exception) {
        inf.broken = true
        inf.rootTag = null
        inf.refs.clear()
    }
}

internal fun parseI3d(ins: InputStream, inf: Info) {
    try {
        BufferedReader(InputStreamReader(ins, Charsets.ISO_8859_1), 1 shl 16).use { r ->
            while (true) {
                val line = r.readLine() ?: break
                for (m in FILE_RE.findAll(line)) inf.refs.add(m.groupValues[1])
            }
        }
    } catch (e: Exception) {
        // нечитаемый i3d: ссылки просто не проверяются
    }
}

// ------------------------------------------------------------------ проход 1: чтение структуры
fun scan(src: Source, cancel: () -> Boolean = { false }): LinkedHashMap<String, Info> {
    val m = LinkedHashMap<String, Info>()
    src.each { name, size, stream ->
        if (cancel()) throw CancellationException()
        val inf = Info(name, if (size < 0) 0L else size)
        val l = name.lowercase()
        if (l.endsWith(".xml")) {
            stream().use { parseXml(it, inf) }
        } else if (l.endsWith(".i3d")) {
            stream().use { parseI3d(it, inf) }
        }
        m[name] = inf
    }
    return m
}

// ------------------------------------------------------------------ раскладка по папкам
private fun plan(infos: Map<String, Info>, sort: Boolean, log: Logger): LinkedHashMap<String, String> {
    val fin = LinkedHashMap<String, String>()
    for (k in infos.keys) fin[k] = k

    val tops = infos.keys.map { if ('/' in it) it.substringBefore('/') else null }.toSet()
    if (tops.size == 1 && null !in tops) {
        val top = tops.first()!!
        if (top != "maps" && top != "embeddedMods") {
            log(
                "WARN",
                tr(
                    "Всё лежит во вложенной папке $top: использую её как корень",
                    "Усе лежить у вкладеній теці $top: використовую її як корінь"
                )
            )
            val pre = "$top/"
            for (k in infos.keys) fin[k] = k.substring(pre.length)
        }
    }
    if (sort) sortLoose(infos, fin, log)
    return fin
}

private fun sortLoose(infos: Map<String, Info>, fin: LinkedHashMap<String, String>, log: Logger) {
    val loose = fin.entries.filter { '/' !in it.value }.map { it.key }
    var mapname = "map"
    for (o in loose) {
        val f = fin[o]!!
        val lf = f.lowercase()
        if (lf.endsWith(".i3d") && !lf.startsWith("sounds")) {
            mapname = f.dropLast(4)
            break
        }
    }
    val used = HashSet<String>(fin.values)
    var moved = 0
    for (o in loose) {
        val k = fin[o]!!
        val l = k.lowercase()
        val stem = l.substringBefore('.')
        if (l == "moddesc.xml" || l.endsWith(".lua") || ICON_PREVIEW_RE.matches(l)) continue
        val dst: String = when {
            stem in SCRIPT_XMLS && l.endsWith(".xml") -> "maps/scripts"
            l.startsWith("sounds.") || l.startsWith("overview.") -> "maps"
            l.endsWith(".gdm") || l.endsWith(".grle") || "_weight." in l ||
                l.startsWith("dem.") || l.startsWith("blockmask") ||
                l.startsWith("gen_") || l.startsWith("infolayer_") -> "maps/data"
            l.endsWith(".ast") -> "maps/$mapname/fillPlanes"
            TEX_RE.containsMatchIn(l) -> "maps/$mapname/textures/terrain"
            ".i3d" in l -> "maps"
            l.endsWith(".xml") && infos[o]?.rootTag == "map" -> "maps"
            else -> {
                log(
                    "WARN",
                    tr(
                        "Не знаю, куда положить: $k (оставлено в корне)",
                        "Не знаю, куди покласти: $k (залишено в корені)"
                    )
                )
                continue
            }
        }
        val nf = "$dst/$k"
        if (nf in used) {
            log(
                "WARN",
                tr(
                    "Файл $nf уже существует, $k оставлен в корне",
                    "Файл $nf уже існує, $k залишено в корені"
                )
            )
            continue
        }
        used.remove(k)
        used.add(nf)
        fin[o] = nf
        moved++
    }
    log("INFO", tr("Разложено файлов: $moved", "Розкладено файлів: $moved"))
}

// ------------------------------------------------------------------ modDesc.xml
private fun List<String>.pickImg(): String? =
    minByOrNull { if (it.lowercase().endsWith(".png")) 0 else 1 }

private fun genModDesc(
    byFinal: Map<String, Info>, title: String, author: String, version: String,
    desc: String, iconOverride: String?, log: Logger
): String? {
    val rels = byFinal.keys.sorted()
    val cfg = rels.firstOrNull { CFG_RE.matches(it) && byFinal[it]?.rootTag == "map" }
    if (cfg == null) {
        log(
            "ERR",
            tr(
                "Не нашёл конфиг карты (maps/*.xml с тегом <map>). modDesc не создан.",
                "Не знайшов конфіг карти (maps/*.xml з тегом <map>). modDesc не створено."
            )
        )
        log(
            "HINT",
            tr(
                "Как исправить: включи «Разложить файлы по папкам» — тогда приложение само найдёт файл карты. Или проверь, что выбрал нужный zip/папку.",
                "Як виправити: увімкни «Розкласти файли по теках» — тоді застосунок сам знайде файл карти. Або перевір, що обрав потрібний zip/теку."
            )
        )
        return null
    }
    val rootPreview = rels.filter { PREVIEW_RE.matches(it) }.pickImg()
    var icon = iconOverride ?: rels.filter { ICON_RE.matches(it) }.pickImg() ?: rootPreview ?: ""
    if (icon.isEmpty()) {
        val ov = rels.filter { OVERVIEW_RE.matches(it) }.pickImg()
        if (ov != null) {
            icon = ov
            log(
                "INFO",
                tr(
                    "Иконки нет — использую картинку карты: $ov",
                    "Іконки немає — використовую картинку карти: $ov"
                )
            )
        }
    }
    if (icon.isEmpty()) {
        log(
            "WARN",
            tr(
                "В карте нет картинки (icon*.png). У мода не будет иконки.",
                "У карті немає картинки (icon*.png). У мода не буде іконки."
            )
        )
        log(
            "HINT",
            tr(
                "Как исправить: нажми «Картинка карты» и выбери любую картинку — она станет иконкой мода.",
                "Як виправити: натисни «Картинка карти» й обери будь-яку картинку — вона стане іконкою мода."
            )
        )
    }
    val preview = rootPreview ?: icon

    fun opt(attr: String, path: String) = if (path in byFinal) " $attr=\"$path\"" else ""

    val items = rels.filter {
        EMBEDDED_RE.matches(it) && byFinal[it]?.rootTag in setOf("placeable", "vehicle", "handTool")
    }
    val luas = rels.filter { '/' !in it && REGISTER_RE.matches(it) }
    val t = esc(title)
    val d = esc(desc.ifBlank { title })

    val sb = StringBuilder()
    sb.append("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\" ?>\n")
    sb.append("<modDesc descVersion=\"$DESC_VERSION\">\n")
    sb.append("    <author>${esc(author)}</author>\n")
    sb.append("    <version>${esc(version)}</version>\n")
    sb.append("    <title><en>$t</en><ru>$t</ru><uk>$t</uk></title>\n")
    sb.append("    <description><en>$d</en><ru>$d</ru><uk>$d</uk></description>\n")
    sb.append("    <iconFilename>$icon</iconFilename>\n")
    sb.append("    <multiplayer supported=\"true\" />\n")
    sb.append("    <maps>\n")
    sb.append("        <map id=\"${safeName(title)}\" className=\"Mission00\" ")
    sb.append("filename=\"\$dataS/scripts/mission00.lua\" configFilename=\"$cfg\"")
    sb.append(opt("defaultVehiclesXMLFilename", "maps/scripts/vehicles.xml"))
    sb.append(" defaultHandToolsXMLFilename=\"\$dataS/maps/handTools.xml\"")
    sb.append(opt("defaultPlaceablesXMLFilename", "maps/scripts/placeables.xml"))
    sb.append(opt("defaultItemsXMLFilename", "maps/scripts/items.xml"))
    sb.append(">\n")
    sb.append("            <title><en>$t</en><ru>$t</ru><uk>$t</uk></title>\n")
    sb.append("            <description><en>$d</en><ru>$d</ru><uk>$d</uk></description>\n")
    sb.append("            <iconFilename>$preview</iconFilename>\n")
    sb.append("        </map>\n")
    sb.append("    </maps>\n")
    if (items.isNotEmpty()) {
        sb.append("    <storeItems>\n")
        for (r in items) sb.append("        <storeItem xmlFilename=\"$r\" />\n")
        sb.append("    </storeItems>\n")
    }
    if (luas.isNotEmpty()) {
        sb.append("    <extraSourceFiles>\n")
        for (l in luas) sb.append("        <sourceFile filename=\"$l\" />\n")
        sb.append("    </extraSourceFiles>\n")
    }
    sb.append("</modDesc>\n")
    log(
        "INFO",
        tr(
            "Создан modDesc.xml (карта: $cfg, встроенных предметов: ${items.size})",
            "Створено modDesc.xml (карта: $cfg, вбудованих предметів: ${items.size})"
        )
    )
    return sb.toString()
}

// ------------------------------------------------------------------ проверка
private class CheckResult(val errors: Int, val warnings: Int, val caseFixes: Map<String, String>)

private fun check(byFinal: Map<String, Info>, log: Logger, quiet: Boolean = false): CheckResult {
    val silent: Logger = { _, _ -> }
    val emit: Logger = if (quiet) silent else log
    val low = HashMap<String, String>()
    for (k in byFinal.keys) low[k.lowercase()] = k
    var errs = 0
    var warns = 0
    val hinted = HashSet<String>()
    val fixes = LinkedHashMap<String, String>()

    fun hint(key: String, ru: String, uk: String) {
        if (hinted.add(key)) emit("HINT", tr(ru, uk))
    }

    fun err(msg: String) {
        errs++
        if (errs <= REPORT_LIMIT) emit("ERR", msg)
    }

    fun warn(msg: String) {
        warns++
        if (warns <= REPORT_LIMIT) emit("WARN", msg)
    }

    fun verify(rel0: String, base: String, owner: String) {
        if (rel0.isEmpty() || rel0.startsWith('$') || "://" in rel0) return
        val rel = rel0.replace('\\', '/')
        val p = norm(if (base.isEmpty()) rel else "$base/$rel")
        if (p in byFinal) return
        val hit = low[p.lowercase()]
        if (hit != null) {
            err(
                tr(
                    "$owner: $rel — в zip файл называется $hit (Android различает регистр букв!)",
                    "$owner: $rel — у zip файл називається $hit (Android розрізняє регістр літер!)"
                )
            )
            hint(
                "case",
                "Как исправить: включи галочку «Исправлять регистр имён» — приложение переименует файл само. Или переименуй его вручную точно как в ссылке.",
                "Як виправити: увімкни галочку «Виправляти регістр імен» — застосунок сам перейменує файл. Або перейменуй його вручну точно як у посиланні."
            )
            if (hit !in fixes && p !in fixes.values) fixes[hit] = p
        } else {
            err(tr("$owner: не найден файл $rel", "$owner: не знайдено файл $rel"))
            hint(
                "missing",
                "Как исправить: добавь этот файл в карту (в ту же папку) или удали ссылку на него из XML. Если файл из другой карты — скопируй его оттуда.",
                "Як виправити: додай цей файл у карту (в ту саму теку) або видали посилання на нього з XML. Якщо файл з іншої карти — скопіюй його звідти."
            )
        }
    }

    if ("modDesc.xml" !in byFinal) {
        err(tr("modDesc.xml должен лежать в корне zip.", "modDesc.xml має лежати в корені zip."))
    }
    var i3d = 0
    var xml = 0
    var tex = 0
    var data = 0
    var snd = 0
    for (r in byFinal.keys.sorted()) {
        val inf = byFinal[r]!!
        val lr = r.lowercase()
        if (lr.endsWith(".i3d")) i3d++
        if (lr.endsWith(".xml")) xml++
        if (lr.endsWith(".png") || lr.endsWith(".dds") || lr.endsWith(".jpg")) tex++
        if (lr.endsWith(".gdm") || lr.endsWith(".grle")) data++
        if (lr.endsWith(".ogg") || lr.endsWith(".wav")) snd++
        if (NONASCII_RE.containsMatchIn(r)) {
            warn(
                tr(
                    "Пробелы или не-латинские символы в имени: $r",
                    "Пробіли або не-латинські символи в імені: $r"
                )
            )
            hint(
                "ascii",
                "Как исправить: переименуй файл латиницей, без пробелов и русских букв (например, My_Map.xml) и поправь ссылки на него.",
                "Як виправити: перейменуй файл латиницею, без пробілів і українських літер (наприклад, My_Map.xml) та поправ посилання на нього."
            )
        }
        if (lr.endsWith(".i3d") && "$r.shapes" !in byFinal) {
            warn(
                tr(
                    "Нет $r.shapes (если в i3d есть геометрия, игра её не загрузит)",
                    "Немає $r.shapes (якщо в i3d є геометрія, гра її не завантажить)"
                )
            )
            hint(
                "shapes",
                "Как исправить: положи рядом файл с таким же именем и окончанием .shapes (он создаётся вместе с .i3d). Если в i3d нет геометрии, предупреждение можно игнорировать.",
                "Як виправити: поклади поруч файл з таким самим іменем і закінченням .shapes (він створюється разом з .i3d). Якщо в i3d немає геометрії, попередження можна ігнорувати."
            )
        }
        if (lr.endsWith(".xml")) {
            if (inf.broken || inf.rootTag == null) {
                err(tr("Сломанный XML $r", "Зламаний XML $r"))
                hint(
                    "xml",
                    "Как исправить: открой файл в текстовом редакторе и проверь, что все теги закрыты (<тег> ... </тег>). Часто помогает заменить файл на оригинальный из карты.",
                    "Як виправити: відкрий файл у текстовому редакторі й перевір, що всі теги закриті (<тег> ... </тег>). Часто допомагає замінити файл на оригінальний з карти."
                )
                continue
            }
            for (ref in inf.refs) verify(ref, "", r)
        } else if (lr.endsWith(".i3d")) {
            val dir = r.substringBeforeLast('/', "")
            for (ref in inf.refs) verify(ref, dir, r)
        }
    }
    if (i3d == 0) {
        err(
            tr(
                "В карте нет ни одного файла .i3d — мод получится пустым",
                "У карті немає жодного файлу .i3d — мод вийде порожнім"
            )
        )
        hint(
            "noi3d",
            "Как исправить: проверь, что выбрал нужный zip/папку: в карте должен быть файл .i3d (обычно в папке maps). Если файлы лежат кучей — включи «Разложить файлы по папкам».",
            "Як виправити: перевір, що обрав потрібний zip/теку: у карті має бути файл .i3d (зазвичай у теці maps). Якщо файли лежать купою — увімкни «Розкласти файли по теках»."
        )
    }
    val d = byFinal["modDesc.xml"]
    if (d != null && !d.broken && d.rootTag != null) {
        if (d.descVersion.isNullOrEmpty()) {
            err(tr("В modDesc.xml нет descVersion", "У modDesc.xml немає descVersion"))
            hint(
                "descv",
                "Как исправить: первая строка modDesc.xml должна быть такой: <modDesc descVersion=\"2\">. Или удали modDesc.xml — приложение создаст его само.",
                "Як виправити: перший рядок modDesc.xml має бути таким: <modDesc descVersion=\"2\">. Або видали modDesc.xml — застосунок створить його сам."
            )
        }
        if (!d.hasMap) {
            err(
                tr(
                    "В modDesc.xml нет блока <maps><map ...>",
                    "У modDesc.xml немає блоку <maps><map ...>"
                )
            )
            hint(
                "nomap",
                "Как исправить: удали свой modDesc.xml из карты — приложение создаст правильный.",
                "Як виправити: видали свій modDesc.xml з карти — застосунок створить правильний."
            )
        }
        if (!d.hasVersion || !d.hasAuthor) {
            warn(
                tr(
                    "В modDesc.xml нет <version> или <author>",
                    "У modDesc.xml немає <version> або <author>"
                )
            )
            hint(
                "verauth",
                "Как исправить: добавь <author>Имя</author> и <version>1.0.0.0</version> в modDesc.xml (или удали его — приложение создаст сам).",
                "Як виправити: додай <author>Ім'я</author> і <version>1.0.0.0</version> у modDesc.xml (або видали його — застосунок створить сам)."
            )
        }
        if (d.iconText.isNullOrBlank()) {
            warn(
                tr(
                    "У мода нет иконки (в modDesc.xml пустой <iconFilename>)",
                    "У мода немає іконки (в modDesc.xml порожній <iconFilename>)"
                )
            )
            hint(
                "noicon",
                "Как исправить: нажми «Картинка карты» и выбери картинку, затем удали старый modDesc.xml из карты — приложение создаст новый с иконкой.",
                "Як виправити: натисни «Картинка карти» й обери картинку, потім видали старий modDesc.xml з карти — застосунок створить новий з іконкою."
            )
        }
    }
    if (!quiet) {
        val total = byFinal.values.sumOf { it.size }
        log(
            "INFO",
            tr(
                "Файлов: ${byFinal.size}, размер: ${total / 1048576} МБ",
                "Файлів: ${byFinal.size}, розмір: ${total / 1048576} МБ"
            )
        )
        log(
            "INFO",
            tr(
                "Содержимое: карт(.i3d) $i3d, xml $xml, картинок/текстур $tex, данных карты $data, звуков $snd",
                "Вміст: карт(.i3d) $i3d, xml $xml, картинок/текстур $tex, даних карти $data, звуків $snd"
            )
        )
        if (errs > REPORT_LIMIT || warns > REPORT_LIMIT) {
            log(
                "INFO",
                tr(
                    "Показаны первые $REPORT_LIMIT ошибок и предупреждений каждого вида",
                    "Показано перші $REPORT_LIMIT помилок і попереджень кожного виду"
                )
            )
        }
        log(
            "INFO",
            tr(
                "Ошибок: $errs, предупреждений: $warns",
                "Помилок: $errs, попереджень: $warns"
            )
        )
    }
    return CheckResult(errs, warns, fixes)
}

// ------------------------------------------------------------------ подготовка (проход 1)
fun prepare(src: Source, o: Options, log: Logger, cancel: () -> Boolean = { false }): Prepared? {
    log(
        "INFO",
        tr(
            "Читаю структуру (ничего не распаковывается)...",
            "Читаю структуру (нічого не розпаковується)..."
        )
    )
    val infos = scan(src, cancel)
    if (infos.isEmpty()) {
        log("ERR", tr("В выбранном zip/папке нет файлов", "У вибраному zip/теці немає файлів"))
        return null
    }
    log("INFO", tr("Найдено файлов: ${infos.size}", "Знайдено файлів: ${infos.size}"))
    val fin = plan(infos, o.sort, log)

    val extra = LinkedHashMap<String, ByteArray>()
    val extraInfos = LinkedHashMap<String, Info>()

    fun buildFinal(): LinkedHashMap<String, Info> {
        val m = LinkedHashMap<String, Info>()
        for ((orig, f) in fin) m[f] = infos[orig]!!
        for ((n, inf) in extraInfos) m[n] = inf
        return m
    }

    var byFinal = buildFinal()
    val hasModDesc = "modDesc.xml" in byFinal

    var iconName: String? = null
    val userIcon = o.icon
    if (userIcon != null) {
        val n = if ("icon.png" in byFinal) "icon_map.png" else "icon.png"
        extra[n] = userIcon
        extraInfos[n] = Info(n, userIcon.size.toLong())
        iconName = n
        byFinal = buildFinal()
        if (hasModDesc) {
            log(
                "WARN",
                tr(
                    "В карте уже есть modDesc.xml: картинка добавлена как $n, но в modDesc.xml не прописана. Удали старый modDesc.xml из карты, чтобы приложение создало новый.",
                    "У карті вже є modDesc.xml: картинку додано як $n, але в modDesc.xml не прописано. Видали старий modDesc.xml з карти, щоб застосунок створив новий."
                )
            )
        } else {
            log("INFO", tr("Добавлена картинка карты: $n", "Додано картинку карти: $n"))
        }
    }

    if (!hasModDesc) {
        val title = o.title.ifBlank { src.baseName.replace('_', ' ') }
        val author = o.author.ifBlank { "Unknown" }
        val version = o.version.ifBlank { "1.0.0.0" }
        val gen = genModDesc(byFinal, title, author, version, o.description, iconName, log)
            ?: return null
        val bytes = gen.toByteArray(Charsets.UTF_8)
        val inf = Info("modDesc.xml", bytes.size.toLong())
        parseXml(ByteArrayInputStream(bytes), inf)
        extra["modDesc.xml"] = bytes
        extraInfos["modDesc.xml"] = inf
        byFinal = buildFinal()
    }

    if (o.fixCase) {
        val dry = check(byFinal, log, true)
        if (dry.caseFixes.isNotEmpty()) {
            val ren = LinkedHashMap<String, String>(dry.caseFixes)
            for ((k, v) in dry.caseFixes) {
                if (k.lowercase().endsWith(".i3d") && "$k.shapes" in byFinal && "$v.shapes" !in byFinal) {
                    ren["$k.shapes"] = "$v.shapes"
                }
            }
            var n = 0
            for (e in fin.entries) {
                val nf = ren[e.value]
                if (nf != null) {
                    log("INFO", "  ${e.value} -> $nf")
                    e.setValue(nf)
                    n++
                }
            }
            byFinal = buildFinal()
            log(
                "INFO",
                tr(
                    "Исправлен регистр имён файлов: $n",
                    "Виправлено регістр імен файлів: $n"
                )
            )
        }
    }

    val res = check(byFinal, log)
    return Prepared(fin, extra, res.errors, res.warnings)
}

// ------------------------------------------------------------------ упаковка (проход 2)
fun pack(
    src: Source,
    p: Prepared,
    out: OutputStream,
    log: Logger,
    onProgress: (Int, Int) -> Unit = { _, _ -> },
    cancel: () -> Boolean = { false }
): Int {
    val total = p.fin.size + p.extra.size
    var i = 0
    val seen = HashSet<String>()
    val buf = ByteArray(1 shl 20)
    val now = System.currentTimeMillis()
    ZipOutputStream(BufferedOutputStream(out, 1 shl 16)).use { z ->
        z.setLevel(1)
        for (name in p.extra.keys.sortedBy { it != "modDesc.xml" }) {
            val e = ZipEntry(name)
            e.time = now
            z.setLevel(if (isStored(name)) 0 else 1)
            z.putNextEntry(e)
            z.write(p.extra[name]!!)
            z.closeEntry()
            seen.add(name)
            i++
        }
        onProgress(i, total)
        src.each { name, size, stream ->
            if (cancel()) throw CancellationException()
            val f = p.fin[name] ?: return@each
            if (!seen.add(f)) {
                log("WARN", tr("Дубликат пропущен: $f", "Дублікат пропущено: $f"))
                return@each
            }
            if (size >= 50L * 1048576) {
                log("INFO", tr("Большой файл: $f (${size / 1048576} МБ)", "Великий файл: $f (${size / 1048576} МБ)"))
            }
            val e = ZipEntry(f)
            e.time = now
            z.setLevel(if (isStored(f)) 0 else 1)
            z.putNextEntry(e)
            stream().use { ins ->
                while (true) {
                    if (cancel()) throw CancellationException()
                    val n = ins.read(buf)
                    if (n < 0) break
                    z.write(buf, 0, n)
                }
            }
            z.closeEntry()
            i++
            onProgress(i, total)
            if (i % 100 == 0 || i == total) {
                log("INFO", tr("Запаковано $i/$total", "Запаковано $i/$total"))
            }
        }
    }
    return i
}

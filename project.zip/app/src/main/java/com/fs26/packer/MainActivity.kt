package com.fs26.packer

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import java.util.Locale
import java.util.concurrent.CancellationException

class MainActivity : Activity() {

    private lateinit var scroll: ScrollView
    private lateinit var tvSrc: TextView
    private lateinit var etTitle: EditText
    private lateinit var etAuthor: EditText
    private lateinit var etVersion: EditText
    private lateinit var etDesc: EditText
    private lateinit var cbSort: CheckBox
    private lateinit var cbFix: CheckBox
    private lateinit var cbForce: CheckBox
    private lateinit var btnZip: Button
    private lateinit var btnDir: Button
    private lateinit var btnIcon: Button
    private lateinit var btnCheck: Button
    private lateinit var btnPack: Button
    private lateinit var btnCancel: Button
    private lateinit var btnCopy: Button
    private lateinit var btnRu: Button
    private lateinit var btnUk: Button
    private lateinit var ivIcon: ImageView
    private lateinit var pb: ProgressBar
    private lateinit var tvLog: TextView

    private val logBuf = SpannableStringBuilder()
    private var srcUri: Uri? = null
    private var srcIsDir = false
    private var srcBase = ""
    private var srcShown = ""
    private var prepared: Prepared? = null
    private var iconBytes: ByteArray? = null

    @Volatile
    private var busy = false

    @Volatile
    private var cancelled = false

    private var lastPct = -1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("fs26", Context.MODE_PRIVATE)
        Lang.uk = if (prefs.contains("uk")) prefs.getBoolean("uk", false)
        else Locale.getDefault().language == "uk"
        buildUi()
        logMsg(
            "INFO",
            tr(
                "Выбери ZIP или папку с картой, потом «Проверить» или «Упаковать».",
                "Обери ZIP або теку з картою, потім «Перевірити» або «Запакувати»."
            )
        )
    }

    private fun setLang(uk: Boolean) {
        Lang.uk = uk
        getSharedPreferences("fs26", Context.MODE_PRIVATE).edit().putBoolean("uk", uk).apply()
        buildUi()
    }

    // ---------------------------------------------------------------- интерфейс
    private fun buildUi() {
        // запоминаем, что уже введено
        val title = if (::etTitle.isInitialized) etTitle.text.toString() else ""
        val author = if (::etAuthor.isInitialized) etAuthor.text.toString() else ""
        val version = if (::etVersion.isInitialized) etVersion.text.toString() else "1.0.0.0"
        val desc = if (::etDesc.isInitialized) etDesc.text.toString() else ""
        val sort = if (::cbSort.isInitialized) cbSort.isChecked else false
        val fix = if (::cbFix.isInitialized) cbFix.isChecked else true
        val force = if (::cbForce.isInitialized) cbForce.isChecked else false

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(32), dp(16), dp(24))

        // заголовок и выбор языка
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val h = TextView(this)
        h.text = "FS26 Map Packer"
        h.textSize = 20f
        h.setTypeface(null, Typeface.BOLD)
        head.addView(h, lp(0, wrap, 1f))
        btnRu = Button(this)
        btnRu.text = "РУС"
        btnRu.isEnabled = Lang.uk
        btnRu.setOnClickListener { setLang(false) }
        btnUk = Button(this)
        btnUk.text = "УКР"
        btnUk.isEnabled = !Lang.uk
        btnUk.setOnClickListener { setLang(true) }
        head.addView(btnRu, lp(wrap, wrap))
        head.addView(btnUk, lp(wrap, wrap))
        col.addView(head, lp(match, wrap))

        // источник
        val row1 = LinearLayout(this)
        btnZip = Button(this)
        btnZip.text = tr("ZIP с картой", "ZIP з картою")
        btnZip.setOnClickListener { pickZip() }
        btnDir = Button(this)
        btnDir.text = tr("Папка с картой", "Тека з картою")
        btnDir.setOnClickListener { pickDir() }
        row1.addView(btnZip, lp(0, wrap, 1f))
        row1.addView(btnDir, lp(0, wrap, 1f))
        col.addView(row1, lp(match, wrap))

        tvSrc = TextView(this)
        tvSrc.text = if (srcShown.isEmpty()) tr("Источник не выбран", "Джерело не вибрано") else srcShown
        col.addView(tvSrc, lp(match, wrap))

        // картинка карты
        val row2 = LinearLayout(this)
        row2.gravity = Gravity.CENTER_VERTICAL
        btnIcon = Button(this)
        btnIcon.text = tr("Картинка карты", "Картинка карти")
        btnIcon.setOnClickListener { pickImage() }
        ivIcon = ImageView(this)
        ivIcon.scaleType = ImageView.ScaleType.CENTER_CROP
        val ib = iconBytes
        if (ib != null) {
            ivIcon.setImageBitmap(BitmapFactory.decodeByteArray(ib, 0, ib.size))
        }
        val tvIconHint = TextView(this)
        tvIconHint.text = if (ib != null) {
            tr("Иконка выбрана", "Іконку вибрано")
        } else {
            tr("необязательно: станет иконкой мода", "необов'язково: стане іконкою мода")
        }
        tvIconHint.textSize = 12f
        row2.addView(btnIcon, lp(wrap, wrap))
        if (ib != null) row2.addView(ivIcon, lp(dp(48), dp(48)))
        row2.addView(tvIconHint, lp(wrap, wrap))
        col.addView(row2, lp(match, wrap))

        // поля
        etTitle = edit(tr("Название мода (пусто = по имени файла)", "Назва мода (порожньо = за іменем файлу)"), title)
        etAuthor = edit(tr("Автор (пусто = Unknown)", "Автор (порожньо = Unknown)"), author)
        etVersion = edit(tr("Версия", "Версія"), version)
        etDesc = edit(tr("Описание (пусто = как название)", "Опис (порожньо = як назва)"), desc)
        col.addView(etTitle, lp(match, wrap))
        col.addView(etAuthor, lp(match, wrap))
        col.addView(etVersion, lp(match, wrap))
        col.addView(etDesc, lp(match, wrap))

        cbSort = CheckBox(this)
        cbSort.text = tr(
            "Разложить файлы по папкам (если лежат кучей)",
            "Розкласти файли по теках (якщо лежать купою)"
        )
        cbSort.isChecked = sort
        cbFix = CheckBox(this)
        cbFix.text = tr(
            "Исправлять регистр имён файлов (рекомендуется)",
            "Виправляти регістр імен файлів (рекомендовано)"
        )
        cbFix.isChecked = fix
        cbForce = CheckBox(this)
        cbForce.text = tr("Упаковать, даже если есть ошибки", "Запакувати, навіть якщо є помилки")
        cbForce.isChecked = force
        col.addView(cbSort, lp(match, wrap))
        col.addView(cbFix, lp(match, wrap))
        col.addView(cbForce, lp(match, wrap))

        // действия
        val row3 = LinearLayout(this)
        btnCheck = Button(this)
        btnCheck.text = tr("Проверить", "Перевірити")
        btnCheck.setOnClickListener { onCheck() }
        btnPack = Button(this)
        btnPack.text = tr("Упаковать", "Запакувати")
        btnPack.setOnClickListener { onPack() }
        row3.addView(btnCheck, lp(0, wrap, 1f))
        row3.addView(btnPack, lp(0, wrap, 1f))
        col.addView(row3, lp(match, wrap))

        val row4 = LinearLayout(this)
        btnCancel = Button(this)
        btnCancel.text = tr("Отмена", "Скасувати")
        btnCancel.setOnClickListener { cancelled = true }
        btnCopy = Button(this)
        btnCopy.text = tr("Копировать лог", "Копіювати лог")
        btnCopy.setOnClickListener { copyLog() }
        row4.addView(btnCancel, lp(0, wrap, 1f))
        row4.addView(btnCopy, lp(0, wrap, 1f))
        col.addView(row4, lp(match, wrap))

        pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        pb.progress = 0
        col.addView(pb, lp(match, wrap))

        tvLog = TextView(this)
        tvLog.typeface = Typeface.MONOSPACE
        tvLog.textSize = 12f
        tvLog.setTextIsSelectable(true)
        tvLog.setPadding(0, dp(8), 0, 0)
        tvLog.text = logBuf
        col.addView(tvLog, lp(match, wrap))

        scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(col)
        setContentView(scroll)
        setButtons(!busy)
    }

    private fun edit(hint: String, def: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(def)
        e.setSingleLine(true)
        return e
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- выбор источника и картинки
    private fun pickZip() {
        if (busy) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(
            Intent.EXTRA_MIME_TYPES,
            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
        @Suppress("DEPRECATION")
        startActivityForResult(i, 1)
    }

    private fun pickDir() {
        if (busy) return
        @Suppress("DEPRECATION")
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2)
    }

    private fun pickImage() {
        if (busy) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        @Suppress("DEPRECATION")
        startActivityForResult(i, 4)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            1, 2 -> {
                val u = data?.data ?: return
                srcUri = u
                srcIsDir = requestCode == 2
                prepared = null
                val shown: String
                if (srcIsDir) {
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(
                        u, DocumentsContract.getTreeDocumentId(u)
                    )
                    shown = displayName(docUri)
                    srcBase = shown
                } else {
                    shown = displayName(u)
                    srcBase = if (shown.lowercase().endsWith(".zip")) shown.dropLast(4) else shown
                }
                srcShown = (if (srcIsDir) tr("Папка: ", "Тека: ") else "ZIP: ") + shown
                tvSrc.text = srcShown
            }
            3 -> {
                val out = data?.data ?: return
                val p = prepared ?: return
                val src = makeSource() ?: return
                runBg {
                    logMsg(
                        "INFO",
                        tr(
                            "Пакую... не закрывай приложение, экран не погаснет",
                            "Пакую... не закривай застосунок, екран не згасне"
                        )
                    )
                    try {
                        val os = contentResolver.openOutputStream(out, "w")
                            ?: throw IOException("cannot open output file")
                        val n = os.use {
                            pack(src, p, it, this::logMsg, this::onProgress, { cancelled })
                        }
                        logMsg(
                            "INFO",
                            tr(
                                "Готово: ${sizeOf(out) / 1048576} МБ, файлов: $n",
                                "Готово: ${sizeOf(out) / 1048576} МБ, файлів: $n"
                            )
                        )
                    } catch (e: Throwable) {
                        try {
                            DocumentsContract.deleteDocument(contentResolver, out)
                        } catch (ex: Exception) {
                            // файл не удалился: ничего страшного
                        }
                        throw e
                    }
                }
            }
            4 -> {
                val u = data?.data ?: return
                Thread {
                    val bytes = try {
                        imageToIconPng(contentResolver, u)
                    } catch (e: Exception) {
                        null
                    }
                    runOnUiThread {
                        if (bytes == null) {
                            toast(tr("Не удалось прочитать картинку", "Не вдалося прочитати картинку"))
                        } else {
                            iconBytes = bytes
                            buildUi()
                            logMsg(
                                "INFO",
                                tr(
                                    "Картинка карты выбрана: станет иконкой мода",
                                    "Картинку карти вибрано: стане іконкою мода"
                                )
                            )
                        }
                    }
                }.start()
            }
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "map"
        }
        return "map"
    }

    private fun sizeOf(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
        }
        return 0L
    }

    private fun makeSource(): Source? {
        val u = srcUri ?: return null
        return if (srcIsDir) DirSource(contentResolver, u, srcBase)
        else ZipSource(contentResolver, u, srcBase)
    }

    private fun options() = Options(
        etTitle.text.toString().trim(),
        etAuthor.text.toString().trim(),
        etVersion.text.toString().trim(),
        etDesc.text.toString().trim(),
        cbSort.isChecked,
        cbFix.isChecked,
        cbForce.isChecked,
        iconBytes
    )

    // ---------------------------------------------------------------- действия
    private fun onCheck() {
        val src = makeSource() ?: run {
            toast(tr("Сначала выбери ZIP или папку", "Спочатку обери ZIP або теку"))
            return
        }
        val o = options()
        runBg {
            val p = prepare(src, o, this::logMsg, { cancelled })
            if (p != null) {
                if (p.errors == 0) {
                    logMsg("INFO", tr("Проверка пройдена: ошибок нет", "Перевірку пройдено: помилок немає"))
                } else {
                    logMsg("ERR", tr("Найдено ошибок: ${p.errors}", "Знайдено помилок: ${p.errors}"))
                }
            }
        }
    }

    private fun onPack() {
        val src = makeSource() ?: run {
            toast(tr("Сначала выбери ZIP или папку", "Спочатку обери ZIP або теку"))
            return
        }
        val o = options()
        runBg {
            val p = prepare(src, o, this::logMsg, { cancelled }) ?: return@runBg
            if (p.errors > 0 && !o.force) {
                logMsg(
                    "ERR",
                    tr(
                        "Есть ошибки — zip не создан. Исправь их (подсказки выше) или включи «Упаковать, даже если есть ошибки».",
                        "Є помилки — zip не створено. Виправ їх (підказки вище) або увімкни «Запакувати, навіть якщо є помилки»."
                    )
                )
                return@runBg
            }
            prepared = p
            val name = "FS26_${safeName(src.baseName)}.zip"
            logMsg("INFO", tr("Выбери, куда сохранить готовый zip", "Обери, куди зберегти готовий zip"))
            runOnUiThread {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "application/zip"
                i.putExtra(Intent.EXTRA_TITLE, name)
                @Suppress("DEPRECATION")
                startActivityForResult(i, 3)
            }
        }
    }

    private fun runBg(job: () -> Unit) {
        if (busy) return
        busy = true
        cancelled = false
        lastPct = -1
        setButtons(false)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fs26packer:work")
        wl.acquire(6 * 60 * 60 * 1000L)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            try {
                job()
            } catch (e: Throwable) {
                if (e is CancellationException) {
                    logMsg("WARN", tr("Отменено", "Скасовано"))
                } else {
                    logMsg(
                        "ERR",
                        tr("Сбой: ", "Збій: ") + e.javaClass.simpleName + ": " + e.message
                    )
                    if (e.message?.contains("ENOSPC") == true) {
                        logMsg(
                            "HINT",
                            tr(
                                "Как исправить: освободи место на телефоне и повтори.",
                                "Як виправити: звільни місце на телефоні й повтори."
                            )
                        )
                    }
                }
            } finally {
                if (wl.isHeld) wl.release()
                busy = false
                runOnUiThread {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    setButtons(true)
                    pb.progress = 0
                }
            }
        }.start()
    }

    private fun onProgress(done: Int, total: Int) {
        if (total <= 0) return
        val pct = (done.toLong() * 100 / total).toInt()
        if (pct == lastPct) return
        lastPct = pct
        runOnUiThread { pb.progress = pct }
    }

    private fun setButtons(on: Boolean) {
        runOnUiThread {
            btnZip.isEnabled = on
            btnDir.isEnabled = on
            btnIcon.isEnabled = on
            btnCheck.isEnabled = on
            btnPack.isEnabled = on
            btnCancel.isEnabled = !on
        }
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", logBuf.toString()))
        toast(tr("Лог скопирован", "Лог скопійовано"))
    }

    // ---------------------------------------------------------------- лог с цветами
    fun logMsg(level: String, msg: String) {
        runOnUiThread {
            val tag: String
            val color: Int
            when (level) {
                "ERR" -> {
                    tag = tr("[ОШИБКА] ", "[ПОМИЛКА] ")
                    color = Color.parseColor("#D32F2F") // красный
                }
                "WARN" -> {
                    tag = tr("[ВНИМАНИЕ] ", "[УВАГА] ")
                    color = Color.parseColor("#EF6C00") // оранжевый
                }
                "HINT" -> {
                    tag = "   → "
                    color = Color.parseColor("#1565C0") // синий
                }
                else -> {
                    tag = "[ok] "
                    color = Color.parseColor("#424242")
                }
            }
            val start = logBuf.length
            logBuf.append(tag).append(msg).append('\n')
            logBuf.setSpan(
                ForegroundColorSpan(color), start, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            if (level == "ERR" || level == "WARN") {
                logBuf.setSpan(
                    StyleSpan(Typeface.BOLD), start, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            if (logBuf.length > 80000) logBuf.delete(0, 30000)
            tvLog.text = logBuf
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}

package com.fs26.packer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {

    private lateinit var tvSrc: TextView
    private lateinit var etTitle: EditText
    private lateinit var etAuthor: EditText
    private lateinit var etVersion: EditText
    private lateinit var cbSort: CheckBox
    private lateinit var cbForce: CheckBox
    private lateinit var btnZip: Button
    private lateinit var btnDir: Button
    private lateinit var btnCheck: Button
    private lateinit var btnPack: Button
    private lateinit var tvLog: TextView
    private lateinit var scroll: ScrollView

    private val logBuf = StringBuilder()
    private var srcUri: Uri? = null
    private var srcIsDir = false
    private var srcBase = ""
    private var prepared: Prepared? = null

    @Volatile
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(36), dp(16), dp(12))

        val head = TextView(this)
        head.text = "FS26 Map Packer"
        head.textSize = 22f
        head.setTypeface(null, Typeface.BOLD)
        root.addView(head, lp(match, wrap))

        val row1 = LinearLayout(this)
        btnZip = Button(this)
        btnZip.text = "ZIP с картой"
        btnZip.setOnClickListener { pickZip() }
        btnDir = Button(this)
        btnDir.text = "Папка с картой"
        btnDir.setOnClickListener { pickDir() }
        row1.addView(btnZip, lp(0, wrap, 1f))
        row1.addView(btnDir, lp(0, wrap, 1f))
        root.addView(row1, lp(match, wrap))

        tvSrc = TextView(this)
        tvSrc.text = "Источник не выбран"
        root.addView(tvSrc, lp(match, wrap))

        etTitle = edit("Название мода (пусто = по имени файла)", "")
        etAuthor = edit("Автор (пусто = Unknown)", "")
        etVersion = edit("Версия", "1.0.0.0")
        root.addView(etTitle, lp(match, wrap))
        root.addView(etAuthor, lp(match, wrap))
        root.addView(etVersion, lp(match, wrap))

        cbSort = CheckBox(this)
        cbSort.text = "Разложить файлы по папкам (если лежат кучей)"
        cbForce = CheckBox(this)
        cbForce.text = "Упаковать, даже если есть ошибки"
        root.addView(cbSort, lp(match, wrap))
        root.addView(cbForce, lp(match, wrap))

        val row2 = LinearLayout(this)
        btnCheck = Button(this)
        btnCheck.text = "Проверить"
        btnCheck.setOnClickListener { onCheck() }
        btnPack = Button(this)
        btnPack.text = "Упаковать"
        btnPack.setOnClickListener { onPack() }
        row2.addView(btnCheck, lp(0, wrap, 1f))
        row2.addView(btnPack, lp(0, wrap, 1f))
        root.addView(row2, lp(match, wrap))

        scroll = ScrollView(this)
        tvLog = TextView(this)
        tvLog.typeface = Typeface.MONOSPACE
        tvLog.textSize = 12f
        tvLog.setTextIsSelectable(true)
        scroll.addView(tvLog)
        root.addView(scroll, lp(match, 0, 1f))

        setContentView(root)
        logMsg("INFO", "Выбери ZIP или папку с картой, потом «Проверить» или «Упаковать».")
    }

    private fun edit(hint: String, def: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(def)
        e.setSingleLine(true)
        return e
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- выбор источника
    private fun pickZip() {
        if (busy) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(
            Intent.EXTRA_MIME_TYPES,
            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
        @Suppress("DEPRECATION")
        startActivityForResult(i, 1)
    }

    private fun pickDir() {
        if (busy) return
        @Suppress("DEPRECATION")
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            1, 2 -> {
                val u = data?.data ?: return
                srcUri = u
                srcIsDir = requestCode == 2
                prepared = null
                val shown: String
                if (srcIsDir) {
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(
                        u, DocumentsContract.getTreeDocumentId(u)
                    )
                    shown = displayName(docUri)
                    srcBase = shown
                } else {
                    shown = displayName(u)
                    srcBase = if (shown.lowercase().endsWith(".zip")) shown.dropLast(4) else shown
                }
                tvSrc.text = (if (srcIsDir) "Папка: " else "ZIP: ") + shown
            }
            3 -> {
                val out = data?.data ?: return
                val p = prepared ?: return
                val src = makeSource() ?: return
                runBg {
                    logMsg("INFO", "Пакую... не закрывай приложение, экран не погаснет")
                    try {
                        val os = contentResolver.openOutputStream(out, "w")
                            ?: throw IOException("не удалось открыть файл для записи")
                        os.use { pack(src, p, it, this::logMsg) }
                        logMsg("INFO", "Готово: ${sizeOf(out) / 1048576} МБ")
                    } catch (e: Throwable) {
                        try {
                            DocumentsContract.deleteDocument(contentResolver, out)
                        } catch (ex: Exception) {
                            // файл не удалился: ничего страшного
                        }
                        throw e
                    }
                }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "map"
        }
        return "map"
    }

    private fun sizeOf(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
        }
        return 0L
    }

    private fun makeSource(): Source? {
        val u = srcUri ?: return null
        return if (srcIsDir) DirSource(contentResolver, u, srcBase)
        else ZipSource(contentResolver, u, srcBase)
    }

    private fun options() = Options(
        etTitle.text.toString().trim(),
        etAuthor.text.toString().trim(),
        etVersion.text.toString().trim(),
        cbSort.isChecked,
        cbForce.isChecked
    )

    // ---------------------------------------------------------------- действия
    private fun onCheck() {
        val src = makeSource() ?: run {
            toast("Сначала выбери ZIP или папку")
            return
        }
        val o = options()
        runBg {
            val p = prepare(src, o, this::logMsg)
            if (p != null) {
                logMsg("INFO", if (p.errors == 0) "Проверка пройдена: ошибок нет" else "Найдено ошибок: ${p.errors}")
            }
        }
    }

    private fun onPack() {
        val src = makeSource() ?: run {
            toast("Сначала выбери ZIP или папку")
            return
        }
        val o = options()
        runBg {
            val p = prepare(src, o, this::logMsg) ?: return@runBg
            if (p.errors > 0 && !o.force) {
                logMsg("ERR", "Есть ошибки — zip не создан (исправь или включи «Упаковать, даже если есть ошибки»)")
                return@runBg
            }
            prepared = p
            val name = "FS26_${safeName(src.baseName)}.zip"
            logMsg("INFO", "Выбери, куда сохранить готовый zip")
            runOnUiThread {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "application/zip"
                i.putExtra(Intent.EXTRA_TITLE, name)
                @Suppress("DEPRECATION")
                startActivityForResult(i, 3)
            }
        }
    }

    private fun runBg(job: () -> Unit) {
        if (busy) return
        busy = true
        setButtons(false)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fs26packer:work")
        wl.acquire(6 * 60 * 60 * 1000L)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            try {
                job()
            } catch (e: Throwable) {
                logMsg("ERR", "Сбой: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                if (wl.isHeld) wl.release()
                busy = false
                runOnUiThread {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    setButtons(true)
                }
            }
        }.start()
    }

    private fun setButtons(on: Boolean) {
        runOnUiThread {
            btnZip.isEnabled = on
            btnDir.isEnabled = on
            btnCheck.isEnabled = on
            btnPack.isEnabled = on
        }
    }

    fun logMsg(level: String, msg: String) {
        val tag = when (level) {
            "ERR" -> "[ОШИБКА]"
            "WARN" -> "[ВНИМАНИЕ]"
            else -> "[ок]"
        }
        runOnUiThread {
            logBuf.append(tag).append(' ').append(msg).append('\n')
            if (logBuf.length > 60000) logBuf.delete(0, 20000)
            tvLog.text = logBuf.toString()
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}

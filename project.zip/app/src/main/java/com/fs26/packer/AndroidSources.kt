package com.fs26.packer

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

class ZipSource(
    private val cr: ContentResolver,
    private val uri: Uri,
    override val baseName: String
) : Source {

    override fun each(cb: (String, Long, () -> InputStream) -> Unit) {
        // Быстрый путь: произвольный доступ к zip через файловый дескриптор.
        var started = false
        val pfd = try {
            cr.openFileDescriptor(uri, "r")
        } catch (e: Exception) {
            null
        }
        if (pfd != null) {
            try {
                ZipFile("/proc/self/fd/${pfd.fd}").use { z ->
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (e.isDirectory) continue
                        val n = e.name.replace('\\', '/')
                        if (isSkipped(n)) continue
                        started = true
                        cb(n, e.size, { z.getInputStream(e) })
                    }
                }
                return
            } catch (e: IOException) {
                if (started) throw e
                // не получилось открыть как файл — читаем потоком
            } finally {
                try {
                    pfd.close()
                } catch (e: IOException) {
                    // ignore
                }
            }
        }
        // Запасной путь: последовательное чтение потоком.
        val raw = cr.openInputStream(uri) ?: throw IOException("Cannot open zip")
        ZipInputStream(BufferedInputStream(raw, 1 shl 16)).use { zin ->
            val wrapper = object : FilterInputStream(zin) {
                override fun close() {}
            }
            while (true) {
                val e = zin.nextEntry ?: break
                if (e.isDirectory) continue
                val n = e.name.replace('\\', '/')
                if (isSkipped(n)) continue
                cb(n, e.size, { wrapper })
            }
        }
    }
}

class DirSource(
    private val cr: ContentResolver,
    private val tree: Uri,
    override val baseName: String
) : Source {

    private class F(val rel: String, val uri: Uri, val size: Long)

    override fun each(cb: (String, Long, () -> InputStream) -> Unit) {
        val files = ArrayList<F>()

        fun walk(docId: String, prefix: String) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            )
            cr.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (name !in SKIP_DIRS) walk(id, "$prefix$name/")
                    } else {
                        val rel = prefix + name
                        if (!isSkipped(rel)) {
                            files.add(
                                F(rel, DocumentsContract.buildDocumentUriUsingTree(tree, id), size)
                            )
                        }
                    }
                }
            }
        }

        walk(DocumentsContract.getTreeDocumentId(tree), "")
        files.sortBy { it.rel }
        for (f in files) {
            cb(f.rel, f.size, {
                val raw = cr.openInputStream(f.uri) ?: throw IOException("Cannot open ${f.rel}")
                BufferedInputStream(raw, 1 shl 16)
            })
        }
    }
}

/** Берёт любую картинку с телефона и делает из неё квадратную PNG-иконку 512x512. */
fun imageToIconPng(cr: ContentResolver, uri: Uri, size: Int = 512): ByteArray? {
    val bounds = BitmapFactory.Options()
    bounds.inJustDecodeBounds = true
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= size && bounds.outHeight / (sample * 2) >= size) {
        sample *= 2
    }
    val opts = BitmapFactory.Options()
    opts.inSampleSize = sample
    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        ?: return null
    val side = minOf(bmp.width, bmp.height)
    val x = (bmp.width - side) / 2
    val y = (bmp.height - side) / 2
    val square = Bitmap.createBitmap(bmp, x, y, side, side)
    val scaled = Bitmap.createScaledBitmap(square, size, size, true)
    val bos = ByteArrayOutputStream()
    scaled.compress(Bitmap.CompressFormat.PNG, 100, bos)
    return bos.toByteArray()
}
